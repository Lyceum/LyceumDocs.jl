#```julia
#include("myalgo.jl") # reloads the file and any recent changes, ie parameters
#include("myenv.jl")  # reloads the environment
#testalgo()
#```

# This file was generated using Literate.jl, https://github.com/fredrikekre/Literate.jl

