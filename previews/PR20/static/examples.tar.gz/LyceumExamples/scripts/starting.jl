```bash
[host]:~/ > export MUJOCO_KEY_PATH=/home/$user/.mujoco/key.txt # replace with appropriate directory
```

# This file was generated using Literate.jl, https://github.com/fredrikekre/Literate.jl

